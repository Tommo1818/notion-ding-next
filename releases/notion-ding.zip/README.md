# Notion Ding 🔔

> **A satisfying sound reward for your Notion to-do lists.**  
> A lightweight Chrome extension that plays a crisp "ding" sound effect every time you complete a task or check a checkbox in Notion.

---

## ✨ Features

- 🔔 **Satisfying Audio Reward**: Plays a crisp, beloved chime whenever you complete a task.
- 🎯 **Accurate State Detection**: Only plays when checking a task from **unchecked to checked** (never when unchecking).
- 🌐 **Full Domain Coverage**: Works seamlessly on `notion.com`, `notion.so`, and published `notion.site` workspaces.
- 📋 **Supports All Notion Task Formats**:
  - Standard to-do blocks (`/to-do` or `[]`)
  - Notion Database checkboxes (Table, Board / Kanban, List, Gallery, Timeline)
- ⌨️ **Keyboard Support**: Triggers on mouse clicks as well as keyboard shortcuts (`Space`, `Enter`, `Cmd+Enter`, `Ctrl+Enter`).
- 📊 **Tasks Completed Counter**: Keeps track of how many tasks you've completed across your Notion workspaces.
- 🎛️ **Audio & Volume Controls**:
  - Exponential volume scaling across 10 levels for natural auditory perception.
  - Quick **Enable/Disable** toggle switch.
  - **Test Sound 🔔** button to preview audio at the current volume.
- 🌓 **Notion-Native Design**:
  - Built to blend with Notion's design system.
  - Automatic Light & Dark mode support (`prefers-color-scheme`).
  - 100% private: Zero tracking, zero telemetry, no external network requests.

---

## 🔍 Why the Original "Notion Ding" Stopped Working

If you used the original `lucasdellabella/notion-ding` extension, it stopped working due to several breaking changes:

1. **Notion's Domain Migration**: Notion moved its primary domain from `notion.so` to `notion.com` and `notion.site`. The original extension only matched `*.notion.so`.
2. **DOM Architecture Overhaul**: Notion transitioned to StyleX CSS modules and ARIA attributes (`[role="checkbox"]`, `aria-checked`), removing legacy `.check` CSS classes and native `<input>` elements in many views.
3. **Unhandled DOM Exception**: The original script threw `TypeError: element.matches is not a function` because `composedPath()` includes non-element nodes (`Window`, `Document`).
4. **Manifest V3 Web Accessible Resources**: Modern Chrome extensions strictly enforce explicit resource matching in Manifest V3.

**Notion Ding 2.0** resolves all of these issues with a multi-layered event engine and modern Manifest V3 compliance.

---

## 🚀 Installation & Packaged Files

You can install Notion Ding directly in Google Chrome, Microsoft Edge, Brave, or any Chromium-based browser.

### Option 1: Load Unpacked (Recommended for Development)
1. Open your browser and navigate to `chrome://extensions` (or `edge://extensions`).
2. Toggle **Developer mode** to **ON** (top-right switch).
3. Click **Load unpacked** (top-left button).
4. Select this directory (or [`dist/notion-ding`](dist/notion-ding)).
5. The Notion Ding icon will appear in your toolbar!

---

### Option 2: Install from `.crx` Package
1. Run `npm run package` to generate production distribution files.
2. Open `chrome://extensions` with **Developer mode** enabled.
3. Drag and drop [`dist/notion-ding.crx`](dist/notion-ding.crx) directly into the browser window.
4. Confirm installation.

---

## 🧪 Automated Testing

Run the built-in automated test suite:
```bash
npm test
```

Tests verify:
- Manifest V3 configuration, permissions, and domain matching patterns.
- Asset integrity (WAV audio RIFF/WAVE header and PNG icon magic bytes).
- Non-linear exponential volume scaling mathematics.
- Checkbox detection across native inputs, ARIA elements, and SVG checkmarks.
- ComposedPath traversal safety (no unhandled TypeErrors).
- Debouncing and state transition logic (unchecked -> checked).

---

## 📦 Building Distribution Packages

To generate clean `.zip` and `.crx` production packages in `dist/`:
```bash
npm run package
```
